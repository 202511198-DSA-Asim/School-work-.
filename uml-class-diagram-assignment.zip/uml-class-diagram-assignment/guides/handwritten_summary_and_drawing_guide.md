# Handwritten summary and drawing guide

## Copy by hand: project summary
**Project title:** Community Pharmacy Inventory and Sales Management System

**Business idea:** The project proposes a simple information system for a community pharmacy to represent product stock, categories, suppliers, purchase orders, sales, and staff transactions.

**Problem and scope:** Paper or disconnected records can make stock and transaction tracking difficult. The model covers products and categories, suppliers and purchase orders, sales and line items, employee attribution, and optional customer details. It does not cover prescriptions, insurance, accounting integration, delivery, or a deployed application.

**Main classes:** Product stores item details and stock; Category groups products; Supplier stores supplier details; PurchaseOrder records an order to a supplier; PurchaseOrderLine records each ordered item and quantity/cost; Sale records a transaction; SaleLine records each sold item and price; Customer stores optional customer details; Employee records the staff member responsible for a transaction; OrderStatus and SaleStatus define the allowed statuses.

**Relationships:** A category has zero or many products, and each product has one category. A supplier may have many purchase orders, each order has one supplier. Each purchase order contains one or more order lines; each sale contains one or more sale lines. Each line refers to one product. An employee records sales and creates purchase orders for a supplier. Order and sale statuses are enumerations. A sale may have zero or one customer.

## Hand-drawing guide
1. Use a landscape A3 sheet if available; otherwise use two landscape A4 sheets joined neatly, or one large landscape page with legible writing.
2. Draw each class as a rectangle with three compartments: class name, attributes, operations. Use `-` for private attributes and `+` for public operations.
3. Suggested layout (same as the electronic diagram, so no lines cross): row 1: Supplier, PurchaseOrder, PurchaseOrderLine, with OrderStatus above PurchaseOrder. Row 2: Employee on the left, Product and Category on the right. Row 3: Customer, Sale, SaleLine, with SaleStatus below Sale. Leave wide gaps for relationship labels.
4. Write all attributes and operations exactly as listed in Report 2. Do not omit types, parameters, or return types.
5. Draw associations with solid lines and label them: categorises; supplies orders; ordered as; creates; records; optional customer; sold as; contains. Place multiplicities at the correct class ends.
6. Draw composition from PurchaseOrder to PurchaseOrderLine with a **filled diamond at PurchaseOrder**; label multiplicities `1` at PurchaseOrder and `1..*` at PurchaseOrderLine.
7. Draw composition from Sale to SaleLine with a **filled diamond at Sale**; label multiplicities `1` at Sale and `1..*` at SaleLine.
8. For Category–Product, use `1` at Category and `0..*` at Product. For Supplier–PurchaseOrder, use `1` at Supplier and `0..*` at PurchaseOrder.
9. For Product–PurchaseOrderLine and Product–SaleLine, use `1` at Product and `0..*` at the line-item end.
10. For Employee–PurchaseOrder and Employee–Sale, use `1` at Employee and `0..*` at the transaction end.
11. For Customer–Sale, use `0..1` at Customer (each sale has zero or one customer) and `0..*` at Sale (a customer may be associated with many sales).
12. Draw OrderStatus (values PENDING, RECEIVED, CANCELLED) and SaleStatus (PENDING, COMPLETED, CANCELLED) as small boxes marked «enumeration», each joined to its class by a dashed arrow with an open arrowhead pointing at the enumeration. No multiplicity is needed on these.
13. Route Employee–PurchaseOrder and Employee–Sale as right-angle lines from Employee's right side (up to PurchaseOrder, down to Sale) so they do not pass through other boxes.
14. Use a ruler, avoid crossing lines, keep text large enough to read, and check every class against the electronic diagram before submission. The lecturer requires the diagram to be drawn by hand in pen, not printed.
